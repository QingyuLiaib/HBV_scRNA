library(Seurat)
library(ggplot2)
library(dplyr)
library(stringr)
options(Seurat.object.assay.version='v4')
setwd('')

data_dir <- ""
sample_ori_names <- c('CL_3m','CL_6m','CL_12m','CL_27m','HL_3m','HL_6m','HL_12m','HL_27m',
                     'CN_3m','CN_6m','CN_12m','CN_27m','HN_3m','HN_6m','HN_12m','HN_27m')

time = c('3m','6m','12m','27m','3m','6m','12m','27m','3m','6m','12m','27m','3m','6m','12m','27m')

group_names <- c("control","control","control","control",'experiment','experiment','experiment','experiment',
                "control","control","control","control",'experiment','experiment','experiment','experiment')
names(group_names) <- sample_ori_names
names(time) <- sample_ori_names


# read 10X data
HBV.list0 <- lapply(X = sample_ori_names,FUN = function(i) {
  print(i)
  file_path <- file.path(data_dir, time[i],substr(i,1,2), "outs/per_sample_outs",substr(i,1,2),"count/sample_feature_bc_matrix/")
  d10x <- Read10X(file_path)

  colnames(d10x) <- paste(sapply(strsplit(colnames(d10x), split='-'), '[[', 1L), i, sep='-')
  pbmc <- CreateSeuratObject(counts = d10x, project = i, min.cells = ncol(d10x)*0.001, min.features = 200)
  print(file_path)
  pbmc[["sample"]] <- rep(i,nrow(pbmc@meta.data))
  pbmc[["group"]] <- rep(group_names[[i]],nrow(pbmc@meta.data))
  pbmc[["percent.mt"]] <- PercentageFeatureSet(pbmc, pattern = "^mt-")
  pbmc[["percent.rb"]] <- PercentageFeatureSet(pbmc, pattern = "^rp[sl]+")
  pbmc[["log10GenesPerUMI"]] <- log10(pbmc[["nFeature_RNA"]]) / log10(pbmc[["nCount_RNA"]])
  pbmc
  # VlnPlot(pbmc, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3,pt.size=0)
  # pbmc <- subset(pbmc, subset = (nFeature_RNA >= 500) & (nCount_RNA >= 800) & (percent.mt <= 10))
  # pbmc <- NormalizeData(pbmc, verbose = TRUE)
  # pbmc <- SCTransform(pbmc)
  # VlnPlot(pbmc, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3,pt.size=0)
})
saveRDS(object =HBV.list0,'./HBVlist0.rds' )


