library(Seurat)
library(ggplot2)
library(dplyr)
library(DoubletFinder)

setwd('')


HBV.list0 <- readRDS("HBVlist0.rds")

tmp1<- lapply(X = HBV.list0[1:8],FUN = function(x){
  up1 = mean(x$nCount_RNA)+2*sd(x$nCount_RNA)
  up2 = mean(x$nFeature_RNA)+2*sd(x$nFeature_RNA)
  pbmc <- subset(x, subset = (nFeature_RNA >= 500) & (nCount_RNA >= 800) & 
                   (nCount_RNA <= up1) & (nFeature_RNA <= up2) &
                   (percent.mt <= 40))
})

tmp2<- lapply(X = HBV.list0[9:16],FUN = function(x){
  up1 = mean(x$nCount_RNA)+2*sd(x$nCount_RNA)
  up2 = mean(x$nFeature_RNA)+2*sd(x$nFeature_RNA)
  pbmc <- subset(x, subset = (nFeature_RNA >= 500) & (nCount_RNA >= 800) & 
                   (nCount_RNA <= up1) & (nFeature_RNA <= up2) &
                   (percent.mt <= 10))
})
HBV.list1 = c(tmp1,tmp2)

for (idx in 1:length(HBV.list1)){
  data <- NormalizeData(HBV.list1[[idx]])
  data <- ScaleData(data, verbose = FALSE)
  data <- FindVariableFeatures(data, verbose = FALSE)
  data <- RunPCA(data, npcs = 30, verbose = FALSE)
  data <- RunUMAP(data, reduction = "pca", dims = 1:30)
  data <- FindNeighbors(data, reduction = "pca", dims = 1:30)
  data <- FindClusters(data, resolution = 0.5)
  sweep.res.list <- paramSweep_v3(data, PCs = 1:30, sct = FALSE)
  sweep.stats <- summarizeSweep(sweep.res.list, GT = FALSE)
  bcmvn <- find.pK(sweep.stats)
  ## Homotypic Doublet Proportion Estimate -------------------------------------------------------------------------------------
  annotations <- data@meta.data$RNA_snn_res.0.5
  homotypic.prop <- modelHomotypic(annotations)           ## ex: annotations <- sample14@meta.data$ClusteringResults
  nExp_poi <- round(0.075*nrow(data@meta.data))  ## Assuming 7.5% doublet formation rate - tailor for your dataset
  nExp_poi.adj <- round(nExp_poi*(1-homotypic.prop))
  
  ## Run DoubletFinder with varying classification stringencies ----------------------------------------------------------------
  data <- doubletFinder_v3(data, PCs = 1:30, pN = 0.25, pK = 0.09, nExp = nExp_poi, reuse.pANN = FALSE, sct = FALSE)
  ## save results
  HBV.list1[[idx]]$doubFind_res = data@meta.data %>% select(contains('DF.classifications'))
  HBV.list1[[idx]]$doubFind_score = data@meta.data %>% select(contains('pANN'))
}

saveRDS(HBV.list1,'HBVlist1.rds')

scemerge1 = merge(HBV.list1[[1]],HBV.list1[2:length(HBV.list1)])
Idents(scemerge1)='doubFind_res'
scemerge1 = subset(scemerge1,idents='Singlet')
Idents(scemerge1)='sample'
################################################################################
################################################################################
seuratlist = SplitObject(scemerge1,split.by = 'sample')
seuratlist <- lapply(X = seuratlist, FUN = function(x) {
  x <- NormalizeData(x)
  x <- FindVariableFeatures(x, selection.method = "vst", nfeatures = 3000)
})
# find anchors 12 mins
seuratlist_std <- FindIntegrationAnchors(object.list = seuratlist,dims = 1:30)
# integration 20 mins 
sce_std <- IntegrateData(anchorset = seuratlist_std, dims = 1:30)
DefaultAssay(sce_std) <- "integrated"
# Run the standard workflow for visualization and clustering
sce_std <- ScaleData(sce_std, verbose = FALSE)
sce_std <- RunPCA(sce_std, npcs = 30, verbose = FALSE)

#sce_std <- RunUMAP(sce_std, reduction = "pca", dims = 1:15)
sce_std <- RunTSNE(sce_std, reduction = "pca", dims = 1:30)
sce_std <- FindNeighbors(sce_std, reduction = "pca", dims = 1:30)
sce_std <- FindClusters(sce_std, resolution = c(1))
Idents(sce_std)='sample'
sce_std=RenameIdents(sce_std,
                     'CN_3m'='Ctrl_3m',
                     'CN_6m'='Ctrl_6m',
                     'CN_12m'='Ctrl_12m',
                     'CN_27m'='Ctrl_27m',
                     'HN_3m'='HBV_3m',
                     'HN_6m'='HBV_6m',
                     'HN_12m'='HBV_12m',
                     'HN_27m'='HBV_27m',
                     'CL_3m'='Ctrl_3m',
                     'CL_6m'='Ctrl_6m',
                     'CL_12m'='Ctrl_12m',
                     'CL_27m'='Ctrl_27m',
                     'HL_3m'='HBV_3m',
                     'HL_6m'='HBV_6m',
                     'HL_12m'='HBV_12m',
                     'HL_27m'='HBV_27m'
)
sce_std$sample_new = Idents(sce_std)
Idents(sce_std)='sample_new'
sce_std=RenameIdents(sce_std,
                     'Ctrl_3m'='3m',
                     'Ctrl_6m'='6m',
                     'Ctrl_12m'='12m',
                     'Ctrl_27m'='27m',
                     'HBV_3m'='3m',
                     'HBV_6m'='6m',
                     'HBV_12m'='12m',
                     'HBV_27m'='27m')
sce_std$time = Idents(sce_std)

saveRDS(sce_std,'./data/.rds')
####################################################################
Idents(sce_std)='integrated_snn_res.1'
sce_anno=RenameIdents(sce_std,
                      '0'='PV hep',
                      '1'='PV hep',
                      '2'='Macro/Mono',
                      '3'='Neutrophil',
                      '4'='Tcell',
                      '5'='-',
                      '6'='-',
                      '7'='PV hep',
                      '8'='Bcell',
                      '9'='PV hep',
                      '10'='Endothelial',
                      '11'='PV hep',
                      '12'='PV hep',
                      '13'='PV hep',
                      '14'='Kupffer',
                      '15'='Macro/Mono',
                      '16'='Macro/Mono',
                      '17'='NK',
                      '18'='CV hep',
                      '19'='-',#Endothelial PV
                      '20'='Endothelial',#PV
                      '21'='DC',
                      '22'='-',
                      '23'='-',
                      '27'='-',
                      '25'='Kupffer',#PV
                      '26'='-',
                      '27'='Neutrophil',
                      '28'='-',#PV
                      '29'='-',
                      '30'='-',#B
                      '31'='-',
                      '32'='-',
                      '33'='-',#T NK
                      '34'='-',#B T NK
                      '35'='-',#NK DC
                      '36'='-',
                      '37'='-'
)
sce_anno$annotation = Idents(sce_anno)
sce_anno = subset(sce_anno,idents = '-',invert=T)
########
library(Seurat)
DefaultAssay(sce_anno)='integrated'
# sce_anno <- NormalizeData(sce_anno)
# sce_anno <- FindVariableFeatures(sce_anno, verbose = FALSE,nfeatures = 3000)
sce_anno <- ScaleData(sce_anno, verbose = FALSE)
sce_anno <- RunPCA(sce_anno, npcs = 50, verbose = FALSE)
ElbowPlot(sce_anno,ndims = 50)

sce_anno <- RunTSNE(sce_anno, reduction = "pca", dims = 1:40)
sce_anno <- FindNeighbors(sce_anno, reduction = "pca", dims = 1:40)
sce_anno <- FindClusters(sce_anno, resolution = c(2))
###########################################
sce_anno2=RenameIdents(sce_anno,
                       '0'='PV hep',
                       '1'='PV hep',
                       '2'='Macro/Mono',
                       '3'='PV hep',
                       '4'='PV hep',
                       '5'='Neutrophil',
                       '6'='PV hep',
                       '7'='PV hep',
                       '8'='PV hep',
                       '9'='Endothelial',
                       '10'='PV hep',
                       '11'='Bcell',
                       '12'='-',
                       '13'='Kupffer',
                       '14'='Kupffer',
                       '15'='PV hep',
                       '16'='Bcell',
                       '17'='Tcell',
                       '18'='Endothelial',
                       '19'='CV hep',
                       '20'='-',
                       '21'='NK',
                       '22'='Neutrophil',
                       '23'='Macro/Mono',
                       '27'='Tcell',
                       '25'='CV hep',
                       '26'='Endothelial',
                       '27'='Tcell',
                       '28'='-',
                       '29'='DC',
                       '30'='Macro/Mono',
                       '31'='Macro/Mono',
                       '32'='Kupffer',
                       '33'='NK',
                       '34'='Neutrophil',
                       '35'='Endothelial',
                       '36'='-',
                       '37'='-',
                       '38'='-',
                       '39'='-',
                       '40'='-',
                       '41'='-',
                       '42'='-'
)

sce_anno2$annotation = Idents(sce_anno2)
sce_anno2 = subset(sce_anno2,idents = '-',invert=T)
DefaultAssay(sce_anno2)='integrated'#
# sce_anno <- NormalizeData(sce_anno)
# sce_anno <- FindVariableFeatures(sce_anno, verbose = FALSE,nfeatures = 3000)
sce_anno2 <- ScaleData(sce_anno2, verbose = FALSE)
sce_anno2 <- RunPCA(sce_anno2, npcs = 50, verbose = FALSE)
ElbowPlot(sce_anno2,ndims = 50)

sce_anno2 <- RunTSNE(sce_anno2, reduction = "pca", dims = 1:40)
sce_anno2 <- FindNeighbors(sce_anno2, reduction = "pca", dims = 1:40)
sce_anno2 <- FindClusters(sce_anno2, resolution = c(2))
#############
Idents(sce_anno2)='integrated_snn_res.2'
sce_anno3=RenameIdents(sce_anno2,
                       '0'='PV hep',
                       '1'='PV hep',
                       '2'='Macro/Mono',
                       '3'='PV hep',
                       '4'='Neutrophil',
                       '5'='PV hep',
                       '6'='PV hep',
                       '7'='PV hep',
                       '8'='PV hep',
                       '9'='Bcell',
                       '10'='PV hep',
                       '11'='PV hep',#
                       '12'='Kupffer',
                       '13'='Tcell',
                       '14'='PV hep',
                       '15'='Endothelial',
                       '16'='Kupffer',
                       '17'='Bcell',
                       '18'='Endothelial',
                       '19'='CV hep',
                       '20'='NK',
                       '21'='Neutrophil',
                       '22'='Endothelial',
                       '23'='Macro/Mono',
                       '27'='CV hep',
                       '25'='Tcell',
                       '26'='DC',
                       '27'='Tcell',
                       '28'='Macro/Mono',
                       '29'='Macro/Mono',
                       '30'='Kupffer',
                       '31'='NK',
                       '32'='Macro/Mono',
                       '33'='Neutrophil',
                       '34'='Endothelial',
                       '35'='PV hep',
                       '36'='PV hep',
                       '37'='PV hep',
                       '38'='PV hep'
)
sce_anno3$annotation = Idents(sce_anno3)
Idents(sce_anno3)='annotation'
DimPlot(sce_anno3,reduction = 'tsne',raster = F,label = T)
Idents(sce_anno3)='sample'
sce_anno3=RenameIdents(sce_anno3,
                       'CN_3m'='N',
                       'CN_6m'='N',
                       'CN_12m'='N',
                       'CN_27m'='N',
                       'HN_3m'='N',
                       'HN_6m'='N',
                       'HN_12m'='N',
                       'HN_27m'='N',
                       'CL_3m'='L',
                       'CL_6m'='L',
                       'CL_12m'='L',
                       'CL_27m'='L',
                       'HL_3m'='L',
                       'HL_6m'='L',
                       'HL_12m'='L',
                       'HL_27m'='L'
)
sce_anno3$tissue = Idents(sce_anno3)
idL = colnames(sce_anno3)[sce_anno3$annotation%in%c('PV hep','CV hep')&sce_anno3$tissue=='L']
idN = colnames(sce_anno3)[!sce_anno3$annotation%in%c('PV hep','CV hep')&sce_anno3$tissue=='N']

sce_anno3=subset(sce_anno3,cell=c(idL,idN))
##############################
DefaultAssay(sce_anno3)='integrated'
# sce_anno <- NormalizeData(sce_anno)
# sce_anno <- FindVariableFeatures(sce_anno, verbose = FALSE,nfeatures = 3000)
sce_anno3 <- ScaleData(sce_anno3, verbose = FALSE)
sce_anno3 <- RunPCA(sce_anno3, npcs = 50, verbose = FALSE)
ElbowPlot(sce_anno3,ndims = 50)

sce_anno3 <- RunTSNE(sce_anno3, reduction = "pca", dims = 1:40)
sce_anno3 <- FindNeighbors(sce_anno3, reduction = "pca", dims = 1:40)
sce_anno3 <- FindClusters(sce_anno3, resolution = c(2,3,4))
##################################################################################
Idents(sce_anno3)='integrated_snn_res.4'
table(sce_anno3$integrated_snn_res.4,sce_anno3$annotation)
sce_anno4=RenameIdents(sce_anno3,
                       '0'='PV hep',
                       '1'='PV hep',
                       '2'='Macro/Mono',
                       '3'='PV hep',
                       '4'='PV hep',
                       '5'='PV hep',
                       '6'='PV hep',
                       '7'='PV hep',
                       '8'='PV hep',
                       '9'='PV hep',
                       '10'='Neutrophil',
                       '11'='Neutrophil',
                       '12'='Endothelial',
                       '13'='Bcell',
                       '14'='Kupffer',
                       '15'='Bcell',
                       '16'='NK',
                       '17'='PV hep',
                       '18'='Neutrophil',
                       '19'='PV hep',
                       '20'='CV hep',
                       '21'='PV hep',
                       '22'='PV hep',
                       '23'='PV hep',
                       '27'='Tcell',
                       '25'='CV hep',
                       '26'='Tcell',
                       '27'='Macro/Mono',
                       '28'='PV hep',
                       '29'='Endothelial',
                       '30'='Kupffer',
                       '31'='Bcell',
                       '32'='Macro/Mono',
                       '33'='DC',
                       '34'='Tcell',
                       '35'='PV hep',
                       '36'='Tcell',
                       '37'='Macro/Mono',
                       '38'='PV hep',
                       '39'='Macro/Mono',
                       '40'='Neutrophil',
                       '41'='NK',
                       '42'='Macro/Mono',
                       '43'='Neutrophil',
                       '44'='CV hep',
                       '45'='Endothelial',
                       '46'='Kupffer'
)

sce_anno4$annotation=Idents(sce_anno4)
saveRDS(sce_anno4,'.rds')
