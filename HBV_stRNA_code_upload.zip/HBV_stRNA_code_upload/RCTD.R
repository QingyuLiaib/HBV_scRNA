setwd(')
library(stringr)
library(Seurat)
library(dplyr)
library(HDF5Array)
library(spacexr)
stRNAlist <- readRDS("stRNAlist.rds")

names(stRNAlist)=unlist(lapply(stRNAlist, function(x){unique(x$sample)}))


sce_anno <- readRDS("/media/amax/data1/HBV_scRNA/data/sce_anno4.rds")
Idents(sce_anno)='annotation'

RCTDresult = list()
for(sample in names(stRNAlist)){
  # set up reference
  Idents(sce_anno)='sample_new'
  tmp <- subset(sce_anno,idents=sample)
  
  tmp <- UpdateSeuratObject(tmp)
  Idents(tmp) <- "annotation"
  Idents(tmp)=make.names(Idents(tmp))
  tmp$annotation=make.names(tmp$annotation)
  # extract information to pass to the RCTD Reference function
  counts <- tmp@assays$RNA@counts
  cluster <- as.factor(tmp$annotation)
  names(cluster) <- colnames(tmp)
  nUMI <- tmp$nCount_RNA
  names(nUMI) <- colnames(tmp)
  reference <- Reference(counts, cluster, nUMI)
  
  # set up query with the RCTD function SpatialRNA
  slide.seq <-stRNAlist[[sample]]
  counts <- slide.seq@assays$Spatial@counts
  coords <- GetTissueCoordinates(slide.seq)
  colnames(coords) <- c("x", "y")
  coords[is.na(colnames(coords))] <- NULL
  query <- SpatialRNA(coords, counts, colSums(counts))
  t=Sys.time()
  RCTD <- create.RCTD(query, reference, max_cores = 8,CELL_MIN_INSTANCE = 10)
  RCTD <- run.RCTD(RCTD, doublet_mode = "full")
  RCTDresult[[sample]]=RCTD
  slide.seq <- AddMetaData(slide.seq, metadata = RCTD@results$weights)
  stRNAlist[[sample]]=slide.seq
  print(Sys.time()-t)
}
saveRDS(stRNAlist,'stRNAlist_RCTD.rds')

#######################################################################
c2l=lapply(RCTDresult,function(x){as.data.frame(x@results$weights)})
c2l=lapply(stRNAlist,function(x){as.data.frame(x@meta.data[,c("Bcell","CV.hep","DC","Endothelial","Kupffer","Macro.Mono","Neutrophil","NK","PV.hep","Tcell")]
)})
names(c2l)=c('Ctrl_3m','Ctrl_6m','Ctrl_12m','Ctrl_27m','HBV_3m','HBV_6m','HBV_12m','HBV_27m')
names(stRNAlist)=c('Ctrl_3m','Ctrl_6m','Ctrl_12m','Ctrl_27m','HBV_3m','HBV_6m','HBV_12m','HBV_27m')

for (i in 1:8){
    c2l[[i]]=  c2l[[i]][!is.na(c2l[[i]][,1]),]
}

for (i in 1:8){
  pos = GetTissueCoordinates(stRNAlist[[i]])
  cellid =intersect(rownames(pos[!is.na(pos$imagerow),]),rownames(c2l[[i]]))
  c2l[[i]] = c2l[[i]][rownames(c2l[[i]])%in%cellid,]
  stRNAlist[[i]]= subset(stRNAlist[[i]],cells = cellid)
}

cell_list  = c('Bcell','CV.hep','DC','Endothelial','Kupffer','Macro.Mono','NK','Neutrophil','PV.hep','Tcell')
#cell_list  = c('Kupffer')

result = list()
for(cell in cell_list){
  dilist = list()
  for(i in 1:8){
    pos = GetTissueCoordinates(stRNAlist[[i]])
    distance = dist(pos)
    distance=as.matrix(distance)
    di=c()
    print(i)
    for(k in 1:ncol(distance)){
      barcode = colnames(distance)[k]
      d = as.data.frame(distance[,k])
      neib =rownames( d)[d$dis<10]
      s_k=0
      if(sum(c2l[[i]][rownames(c2l[[i]])%in%neib,'PV.hep'])>0.1&
         sum(c2l[[i]][rownames(c2l[[i]])%in%neib,'CV.hep'])>0.1
         ){
        PV_ave = sum(c2l[[i]][rownames(c2l[[i]])%in%neib,paste0(cell)])/sum(c2l[[i]][rownames(c2l[[i]])%in%neib,'PV.hep'])
        #PV_ave = PV_ave* sum(c2l[[i]]$`q05cell_abundance_w_sf_PV hep`)/sum(c2l[[i]]$q05cell_abundance_w_sf_Kupffer)
        
        CV_ave = sum(c2l[[i]][rownames(c2l[[i]])%in%neib,paste0(cell)])/sum(c2l[[i]][rownames(c2l[[i]])%in%neib,'CV.hep'])
        #CV_ave = CV_ave* sum(c2l[[i]]$`q05cell_abundance_w_sf_CV hep`)/sum(c2l[[i]]$q05cell_abundance_w_sf_Kupffer)
        x=mean(CV_ave)-mean(PV_ave)
        names(x)=barcode
        di = c(di,x)

      }
    }
    dilist[[names(stRNAlist)[i]]]=di
  }
  result[[cell]]=dilist
}
#####################################
datalist=list()
for(cell in cell_list){
  a=result[[cell]]
  l = max(unlist(lapply(a,FUN = function(x){length(x)})))
  a=lapply(a, function(x){c(x,rep(NA,l-length(x)))})
  data = data.frame(row.names = 1:l)
  for(i in 1:8){
    da = data.frame(spot_name=names(a[[i]]),value = a[[i]])
    colnames(da)=c(paste0(names(a[i]),'_spot_id'),paste0(names(a[i]),'_RCI_value'))
    data=cbind(data,da)
  }
  datalist[[cell]]=data
}

####################################
gene_list  = c('Cxcl9','Ccl2','Ccl3','Ccl4','Ccl5','Ccl6','Ccl7','Ccl9','Ccl12','Cxcl1','Cxcl2','Cxcl10','Cxcl12','Cxcl13','Cxcl14','Cxcl16','Cx3cl1')

#####################
result = list()
for(gene in gene_list){
  dilist = list()
  for(i in 1:8){
    pos = GetTissueCoordinates(stRNAlist[[i]])
    distance = dist(pos)
    distance=as.matrix(distance)
    exp=stRNAlist[[i]]@assays$Spatial@data[gene,]
    di=c()
    print(i)
    for(k in 1:ncol(distance)){
      barcode = colnames(distance)[k]
      d = as.data.frame(distance[,k])
      neib =rownames(d)[d$dis<10]
      cxcl9exp = exp[neib]
      neib%in%rownames(c2l[[i]])
      a=c2l[[i]]
      s_k=0
      if( #sum(cxcl9exp)>0&
        sum(c2l[[i]][rownames(c2l[[i]])%in%neib,'PV.hep'])>0.1&
        sum(c2l[[i]][rownames(c2l[[i]])%in%neib,'CV.hep'])>0.1
      ){
        PV_ave = sum(cxcl9exp)/sum(c2l[[i]][rownames(c2l[[i]])%in%neib,'PV.hep'])
        #PV_ave = PV_ave* sum(c2l[[i]]$`q05cell_abundance_w_sf_PV hep`)/sum(c2l[[i]]$q05cell_abundance_w_sf_Kupffer)
        
        CV_ave = sum(cxcl9exp)/sum(c2l[[i]][rownames(c2l[[i]])%in%neib,'CV.hep'])
        #CV_ave = CV_ave* sum(c2l[[i]]$`q05cell_abundance_w_sf_CV hep`)/sum(c2l[[i]]$q05cell_abundance_w_sf_Kupffer)
        x = mean(CV_ave)-mean(PV_ave)
        names(x)=barcode
        di = c(di,x)
      }
    }
    dilist[[names(stRNAlist)[i]]]=di
  }
  result[[gene]]=dilist
}









