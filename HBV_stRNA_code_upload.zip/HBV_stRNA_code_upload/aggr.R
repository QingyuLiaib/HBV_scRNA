library(readr)
library(Seurat)
library(hdf5r)
setwd('')

namelist = c('B1-84C','A1-87C','A1-C1','D1-C2','D1-34H','C1-35H','B1-H1','C1-H3')
nams = c('Ctrl_3m','Ctrl_6m','Ctrl_12m','Ctrl_27m','HBV_3m','HBV_6m','HBV_12m','HBV_27m')

names(nams)=namelist
stdata = list()
for (sample in namelist){
  print(sample)
  expr.data <- Seurat::Read10X_h5(filename =  paste0('./ST_data/',sample,'/outs/filtered_feature_bc_matrix.h5' ))
  if(sample %in% c('D1-C2','D1-34H','C1-35H','B1-H1','C1-H3')){rownames(expr.data)=str_sub(rownames(expr.data),6,-1)}
  st <- Seurat::CreateSeuratObject(counts = expr.data, project = sample, assay = 'Spatial')
  
  st$slice <- 1
  st$sample = nams[sample]
  st$region <- 'liver'
  # Load the image data
  img <- Seurat::Read10X_Image(image.dir =paste0('./ST_data/',sample,'/outs/spatial/'))
  Seurat::DefaultAssay(object = img) <- 'Spatial'
  img <- img[colnames(x = st)]
  st[['image']] <- img
  st<- subset(st, subset = nCount_Spatial > 0)
  st <- SCTransform(st, assay = "Spatial", return.only.var.genes = FALSE, verbose = T)
  st <- NormalizeData(st, verbose = FALSE, assay = "Spatial")
  stdata[[nams[sample]]]=st
}

saveRDS(stdata,'stRNAlist.rds')

